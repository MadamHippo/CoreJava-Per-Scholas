package com.perscholas.java_basics.BookPracticeProblems;

public class PracticeBookQuestion5 {
    public static void main(String[] args) {
        // Sales prediction...
        double company_generates = 0.62;
        int total_sales = 4600000;

        double answer = total_sales * company_generates;
        System.out.println(answer);
        // so company will generate over 2.8 million. it prints $2,852,000
    }
}
