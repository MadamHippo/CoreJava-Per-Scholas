package com.perscholas.java_basics.BookPracticeProblems;

public class PracticeBookQuestion6
{
    public static void main(String[] args) {
        //Land calculation
        int one_acre_to_feet = 43560;
        int tract_of_land = 389767;

        int num_of_acres = tract_of_land / one_acre_to_feet;
        System.out.println(num_of_acres);
        // prints out 8 number of acres...
    }
}
