package com.perscholas.java_basics.BookPracticeProblems;

public class PracticeBookQuestion3 {
    public static void main(String[] args) {
        // Practice book question #3, personal information and learning about line breaks
        String name = "Lily He";
        String address = "123 Main Street, Seattle, WA 90000";
        String telephoneNum = "555-5555";
        String collegeMajor = "Candy Making";
        System.out.println(name + "\n" + address + "\n" + telephoneNum + "\n" + collegeMajor);

    }
}
