package com.perscholas.java_basics.Arrays;

import java.util.Arrays;

public class ArrayPracticeAssignment10 {
    public static void main(String[] args) {
        // Create an array that includes an integer, 3 strings, and 1 double. Print the array.
        Object[] array = {2, "Mom", "Pops", "Eden", 2.5};
        System.out.println(Arrays.toString(array));
    }
}
