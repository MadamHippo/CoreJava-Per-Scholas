package com.perscholas.java_basics.BookPracticeProblems.DecisionStructures;

public class SpeedOfSound {
    public static void main(String[] args) {
        String air = "air";
        String water = "water";
        String steel = "steel";
        int distance = 0;
        double travelAirTime = distance / 1100;
    }
}
